-- drop.sql
-- kaitlyn cason : 204411394
-- alexander waz : 504480512

DROP TABLE IF EXISTS Category, Bid, Item, User;
